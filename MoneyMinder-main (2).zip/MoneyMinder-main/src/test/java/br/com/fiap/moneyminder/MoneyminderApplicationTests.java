package br.com.fiap.moneyminder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoneyminderApplicationTests {

	@Test
	void contextLoads() {
	}

}

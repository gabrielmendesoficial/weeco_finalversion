package br.com.fiap.weeco.controller;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.fiap.weeco.model.Produto;
import br.com.fiap.weeco.repository.ProdutoRepository;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("produto")
@Slf4j
public class ProdutoController {

    record TotalPorCategoria (String categoria, BigDecimal valor){} 

    @Autowired
    ProdutoRepository repository;

    @GetMapping
    public Page<Produto> index(
        @RequestParam(required = false) String categoria,
        @PageableDefault(sort = "nome", direction = Direction.ASC) Pageable pageable

    ){
        if (categoria != null){
            return repository.findByCategoriaNome(categoria, pageable);
        }
       
        return repository.findAll(pageable);
    }

    @GetMapping("total-por-categoria")
    public List<TotalPorCategoria> getTotalPorCategoria(){
        var produtos = repository.findAll();

        Map<String, BigDecimal> collect = produtos.stream()
            .collect(
                Collectors.groupingBy(
                    m -> m.getCategoria().getNome(),
                    Collectors.reducing( BigDecimal.ZERO, Produto::getValor, BigDecimal::add)
                )
            );

        return collect
            .entrySet()
            .stream()
            .map(e -> new TotalPorCategoria(e.getKey(), e.getValue()) )
            .toList();

   }


    @PostMapping
    public Produto create(@RequestBody @Valid Produto produto){
        return repository.save(produto);
    }
    
}

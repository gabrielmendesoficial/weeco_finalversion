package br.com.fiap.weeco.config;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

import br.com.fiap.weeco.model.Categoria;
import br.com.fiap.weeco.model.Produto;
import br.com.fiap.weeco.repository.CategoriaRepository;
import br.com.fiap.weeco.repository.ProdutoRepository;

@Configuration
public class DatabaseSeeder implements CommandLineRunner {

    @Autowired
    CategoriaRepository categoriaRepository;

    @Autowired
    ProdutoRepository produtoRepository;

    @Override
    public void run(String... args) throws Exception {

        categoriaRepository.saveAll(
                List.of(
                        Categoria.builder().id(1L).nome("eletrodomestico").build(),
                        Categoria.builder().id(2L).nome("informatica").build(),
                        Categoria.builder().id(3L).nome("perifericos").build(),
                        Categoria.builder().id(4L).nome("acessorios").build()));

        produtoRepository.saveAll(
                List.of(
                        Produto.builder()
                                .id(1L)
                                .descricao("Geladeira")
                                .valor(new BigDecimal(100))
                                .categoria(categoriaRepository.findById(3L).get())
                                .build()
                        // Produto.builder()
                        //         .id(2L)
                        //         .descricao("")
                        //         .valor(new BigDecimal(80))
                        //         .categoria(categoriaRepository.findById(2L).get())
                        //         .build(),
                        // Produto.builder()
                        //         .id(3L)
                        //         .descricao("")
                        //         .valor(new BigDecimal(90))
                        //         .categoria(categoriaRepository.findById(4L).get())
                        //         .build(),
                        // Produto.builder()
                        //         .id(4L)
                        //         .descricao("")
                        //         .valor(new BigDecimal(1000))
                        //         .categoria(categoriaRepository.findById(1L).get())
                        //         .build(),
                        // Produto.builder()
                        //         .id(5L)
                        //         .descricao("")
                        //         .valor(new BigDecimal(250))
                        //         .categoria(categoriaRepository.findById(1L).get())
                        //         .build(),
                        // Produto.builder()
                        //         .id(6L)
                        //         .descricao("")
                        //         .valor(new BigDecimal(50))
                        //         .categoria(categoriaRepository.findById(2L).get())
                        //         .build(),
                        // Produto.builder()
                        //         .id(7L)
                        //         .descricao("")
                        //         .valor(new BigDecimal(400))
                        //         .categoria(categoriaRepository.findById(3L).get())
                        //         .build(),
                        // Produto.builder()
                        //         .id(8L)
                        //         .descricao("")
                        //         .valor(new BigDecimal(500))
                        //         .categoria(categoriaRepository.findById(1L).get())
                        //         .build(),
                        // Produto.builder()
                        //         .id(9L)
                        //         .descricao("")
                        //         .valor(new BigDecimal(55))
                        //         .build(),
                        // Produto.builder()
                        //         .id(10L)
                        //         .descricao("")
                        //         .valor(new BigDecimal(100))
                        //         .build()
                        )

        );

    }

}

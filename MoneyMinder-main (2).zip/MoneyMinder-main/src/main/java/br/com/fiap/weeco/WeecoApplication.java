package br.com.fiap.weeco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeecoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeecoApplication.class, args);
	}

}
